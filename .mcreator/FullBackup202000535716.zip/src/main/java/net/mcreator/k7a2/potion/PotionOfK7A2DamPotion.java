
package net.mcreator.k7a2.potion;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.World;
import net.minecraft.util.ResourceLocation;
import net.minecraft.potion.Potion;
import net.minecraft.potion.EffectType;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effect;
import net.minecraft.entity.ai.attributes.AbstractAttributeMap;
import net.minecraft.entity.LivingEntity;

import net.mcreator.k7a2.procedures.PotionOfK7A2DamPotionStartedappliedProcedure;
import net.mcreator.k7a2.K7a2ModElements;

import java.util.Map;
import java.util.HashMap;

@K7a2ModElements.ModElement.Tag
public class PotionOfK7A2DamPotion extends K7a2ModElements.ModElement {
	@ObjectHolder("k7a2:potion_of_k_7_a_2_dam")
	public static final Effect potion = null;
	@ObjectHolder("k7a2:potion_of_k_7_a_2_dam")
	public static final Potion potionType = null;
	public PotionOfK7A2DamPotion(K7a2ModElements instance) {
		super(instance, 79);
		FMLJavaModLoadingContext.get().getModEventBus().register(this);
	}

	@SubscribeEvent
	public void registerEffect(RegistryEvent.Register<Effect> event) {
		event.getRegistry().register(new EffectCustom());
	}

	@SubscribeEvent
	public void registerPotion(RegistryEvent.Register<Potion> event) {
		event.getRegistry().register(new PotionCustom());
	}
	public static class PotionCustom extends Potion {
		public PotionCustom() {
			super(new EffectInstance(potion, 3600));
			setRegistryName("potion_of_k_7_a_2_dam");
		}
	}

	public static class EffectCustom extends Effect {
		private final ResourceLocation potionIcon;
		public EffectCustom() {
			super(EffectType.HARMFUL, -1103195);
			setRegistryName("potion_of_k_7_a_2_dam");
			potionIcon = new ResourceLocation(
					"k7a2:textures/removal.ai_3cd549b2-8d8d-4305-821c-649f7ecfa191-st-large-507x507-pad-600x600-f8f8f8.png");
		}

		@Override
		public String getName() {
			return "effect.potion_of_k_7_a_2_dam";
		}

		@Override
		public boolean isBeneficial() {
			return false;
		}

		@Override
		public boolean isInstant() {
			return false;
		}

		@Override
		public boolean shouldRenderInvText(EffectInstance effect) {
			return true;
		}

		@Override
		public boolean shouldRender(EffectInstance effect) {
			return true;
		}

		@Override
		public boolean shouldRenderHUD(EffectInstance effect) {
			return true;
		}

		@Override
		public void applyAttributesModifiersToEntity(LivingEntity entity, AbstractAttributeMap attributeMapIn, int amplifier) {
			World world = entity.world;
			double x = entity.getPosX();
			double y = entity.getPosY();
			double z = entity.getPosZ();
			{
				Map<String, Object> $_dependencies = new HashMap<>();
				$_dependencies.put("entity", entity);
				PotionOfK7A2DamPotionStartedappliedProcedure.executeProcedure($_dependencies);
			}
		}

		@Override
		public boolean isReady(int duration, int amplifier) {
			return true;
		}
	}
}
