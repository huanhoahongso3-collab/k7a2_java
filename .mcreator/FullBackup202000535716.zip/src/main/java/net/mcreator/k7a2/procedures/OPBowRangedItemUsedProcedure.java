package net.mcreator.k7a2.procedures;

import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.k7a2.potion.PotionOfK7A2DamPotion;
import net.mcreator.k7a2.K7a2ModElements;

import java.util.Map;

@K7a2ModElements.ModElement.Tag
public class OPBowRangedItemUsedProcedure extends K7a2ModElements.ModElement {
	public OPBowRangedItemUsedProcedure(K7a2ModElements instance) {
		super(instance, 92);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				System.err.println("Failed to load dependency entity for procedure OPBowRangedItemUsed!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(PotionOfK7A2DamPotion.potion, (int) 200, (int) 1));
	}
}
